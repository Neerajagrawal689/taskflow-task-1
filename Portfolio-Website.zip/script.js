/* ===== basic DOM handles ===== */
const body = document.body;
const toggle = document.getElementById('theme-toggle');
const reveals = document.querySelectorAll('.reveal');
const typeEl = document.getElementById('type-text');
const form = document.getElementById('contact-form');
const formStatus = document.getElementById('form-status');
const menuBtn = document.getElementById('menu-btn');
const nav = document.getElementById('nav');

/* ===== mobile menu toggling ===== */
if(menuBtn) {
  menuBtn.addEventListener('click', ()=>{
    nav.classList.toggle('open');
  });
}

/* ===== theme saved state ===== */
if (localStorage.getItem('theme') === 'dark') {
  body.classList.add('dark');
  toggle.textContent = '☀️';
} else {
  toggle.textContent = '🌙';
}
toggle.addEventListener('click', () => {
  body.classList.toggle('dark');
  const t = body.classList.contains('dark') ? 'dark' : 'light';
  localStorage.setItem('theme', t);
  toggle.textContent = t === 'dark' ? '☀️' : '🌙';
});

/* ===== typing effect ===== */
const phrases = [
  "Full Stack Developer 🔧",
  "Frontend Engineer ✨",
  "React · JS · WebPerf",
  "I build production-ready apps"
];
let p=0, l=0, del=false;
function type(){
  const cur = phrases[p];
  if(!del){
    l++;
    typeEl.textContent = cur.slice(0,l);
    if(l===cur.length){ del=true; setTimeout(type,900); return; }
    setTimeout(type,80);
  } else {
    l--;
    typeEl.textContent = cur.slice(0,l);
    if(l===0){ del=false; p=(p+1)%phrases.length; setTimeout(type,300); return; }
    setTimeout(type,40);
  }
}
if(typeEl) type();

/* ===== reveal on scroll (IntersectionObserver) ===== */
const io = new IntersectionObserver((entries) => {
  entries.forEach(e=>{
    if(e.isIntersecting) e.target.classList.add('active');
  });
},{threshold:0.15});
reveals.forEach(r=>io.observe(r));

/* ===== simple contact form handler (demo) ===== */
if(form){
  form.addEventListener('submit', e=>{
    e.preventDefault();
    if(formStatus) formStatus.textContent = 'Sending...';
    // demo: mimic network delay
    setTimeout(()=>{
      form.reset();
      if(formStatus) formStatus.textContent = 'Message sent — thank you!';
      setTimeout(()=>{ if(formStatus) formStatus.textContent=''; },3000);
    },800);
  });
}

/* ===== particle background (lightweight canvas) ===== */
const canvas = document.getElementById('bg-canvas');
if(canvas){
  const ctx = canvas.getContext('2d');
  let w = canvas.width = innerWidth;
  let h = canvas.height = innerHeight;
  window.addEventListener('resize', ()=>{ w = canvas.width = innerWidth; h = canvas.height = innerHeight; init(); });

  class Particle {
    constructor(){
      this.reset();
    }
    reset(){
      this.x = Math.random()*w;
      this.y = Math.random()*h;
      this.vx = (Math.random()-0.5)*0.6;
      this.vy = (Math.random()-0.5)*0.6;
      this.r = 0.6 + Math.random()*2.4;
      this.alpha = 0.15 + Math.random()*0.6;
    }
    update(){
      this.x += this.vx;
      this.y += this.vy;
      if(this.x < -50 || this.x > w+50 || this.y < -50 || this.y > h+50) this.reset();
    }
    draw(){
      ctx.beginPath();
      ctx.fillStyle = `rgba(255,255,255,${this.alpha})`;
      ctx.arc(this.x,this.y,this.r,0,Math.PI*2);
      ctx.fill();
    }
  }

  let particles = [];
  function init(){
    particles = [];
    const count = Math.round((w*h)/80000); // scale with area
    for(let i=0;i<count;i++) particles.push(new Particle());
  }
  let raf=0;
  function anim(){
    ctx.clearRect(0,0,w,h);
    for(let p of particles){ p.update(); p.draw(); }
    raf = requestAnimationFrame(anim);
  }
  init(); anim();

  /* reduce motion if prefers-reduced-motion */
  const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
  if(mq.matches){
    cancelAnimationFrame(raf);
    canvas.style.display = 'none';
  }
}
