# Portfolio-Website (Soft Nexis - 1st Task)

This is a ready-to-deploy developer portfolio built to match the features of the example site and your task requirements (responsive grid, dark mode, typing effect, animated background, scroll reveals, etc.).

## What is included
- `index.html` — main markup (semantic sections, hero, about, skills, experience, projects, contact)
- `style.css` — styling, responsive grid, animated gradient, glass cards
- `script.js` — dark mode, typing effect, scroll reveals, canvas particle background, demo contact handler
- placeholder images: `avatar.jpg`, `proj1.png`, `proj2.png`, `proj3.png` (you should replace these with your images)
- `resume.pdf` — placeholder (replace with actual resume)

## How to use locally
1. Download or clone this folder.
2. Replace `avatar.jpg`, project images and `resume.pdf` with your assets.
3. Open `index.html` in a browser to test locally.

## Deploy (GitHub Pages)
```bash
git init
git add .
git commit -m "Add portfolio site"
git remote add origin https://github.com/username/Portfolio-Website.git
git branch -M main
git push -u origin main
```
Then go to GitHub → Settings → Pages → Branch `main` → root and enable Pages.

## Deploy (Netlify)
Drag & drop the folder to [Netlify Drop](https://app.netlify.com/drop) or connect the GitHub repo in Netlify UI.

## Notes
- Replace placeholder images and resume with your files.
- The contact form is a demo: it does not send emails. Connect a form service (Formspree, Netlify Forms, or a backend) to collect messages.
- The canvas background is lightweight and respects `prefers-reduced-motion`.
